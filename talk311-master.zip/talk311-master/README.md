# talk311
This app (iOS) uses voice activated search for thousands of public contacts in the City of Los Angeles

It uses a search API (AlgoliaSearch), a natural language processing API (wit.ai), and data converted from CityFone's contact directory.

https://www.algolia.com/
https://wit.ai/
http://cityfone.lacity.org/department_drilldown.cfm?SECT=a
