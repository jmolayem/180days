class AddFinishedToResult < ActiveRecord::Migration
  def change
    add_column :results, :finished, :boolean, default: false
  end
end
