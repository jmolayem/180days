Rails.application.config.middleware.use OmniAuth::Builder do
  provider(
    :auth0,
    '4dBUDHm2qR3inPGG4cn4tTKSzgSa0Z5H',
    'H8Zs8yAPeLE4La1cTwRE4DCoiuo5YAHYhUy6WIQoHgxjsaRgnuxMRPDyshYy_lvR',
    'deepmlearning.auth0.com',
    callback_path: "/auth/auth0/callback"
  )
end