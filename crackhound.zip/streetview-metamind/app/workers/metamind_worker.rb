class MetamindWorker
	include Sidekiq::Worker

	def perform(result_id, images)
		result = Result.find result_id
		images.each do |image|
			result.responses << JSON.parse(Metamind.post_image(image))
			result.save!
		end
		result.update!(finished: true)
	end
end